using Terraria.ModLoader;

namespace Illuminum
{
	public class Illuminum : Mod
	{
	}
}